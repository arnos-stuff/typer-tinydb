
import typer

from .typerdb import cfg

__name__ = 'typer_tinydb'

__qualname__ = 'typer-tinydb'

cfg(prog_name='typer-tinydb')