
import typer

from .tdb import cfg

from .utils import db

__name__ = 'typer_tinydb'

__qualname__ = 'typer-tinydb'

cfg(prog_name='typer-tinydb', pkg_name='typer-tinydb')